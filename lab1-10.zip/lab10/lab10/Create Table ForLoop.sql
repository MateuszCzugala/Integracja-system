CREATE TABLE ForLoop
    (
    ID int NOT NULL IDENTITY (1, 1),
    Name varchar(50) NULL
    )  ON [PRIMARY]
